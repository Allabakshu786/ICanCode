package com.example.xtraticket;

import java.io.Serializable;

public class UserModel implements Serializable {

    private String name, mobile, theatre, nuofTic, time, amt;
    private int id;


    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getMobile() {
        return mobile;
    }

    public void setMobile(String mobile) {
        this.mobile = mobile;
    }

    public String getNuOfTicket() {
        return nuofTic;
    }

    public void setNuOfTicket(String nuofTic) {
        this.nuofTic = nuofTic;
    }

    public String getTime() {
        return time;
    }

    public void setTime(String time) {
        this.time = time;
    }

    public String getAmt() {
        return amt;
    }

    public void setAmt(String amt) {
        this.amt = amt;
    }

    public String getTheatre() {
        return theatre;
    }

    public void setTheatre(String theatre) {
        this.theatre = theatre;
    }

}
