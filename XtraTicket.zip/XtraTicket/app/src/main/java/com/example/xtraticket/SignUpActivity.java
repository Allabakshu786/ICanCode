package com.example.xtraticket;

import android.content.Intent;
import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class SignUpActivity extends AppCompatActivity {

    private Button btnLogin,btnSignup;




    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_ineed);
        btnLogin=(Button)findViewById(R.id.btnLogin);
        btnSignup=(Button)findViewById(R.id.btnSignup);
        final EditText editText = (EditText)findViewById(R.id.editText);
        final EditText editText2 = (EditText)findViewById(R.id.editText2);
        final EditText editText3 = (EditText)findViewById(R.id.editText3);
        final EditText editText4 = (EditText)findViewById(R.id.editText4);
        final EditText editText6 = (EditText)findViewById(R.id.editText6);
        final EditText editText7 = (EditText)findViewById(R.id.editText7);

        btnLogin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(SignUpActivity.this,MainActivity.class);
                startActivity(intent);
            }
        });

        Button btn = (Button)findViewById(R.id.button3);

        btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                if (editText.getText().toString().trim().length() <= 0||editText2.getText().toString().trim().length() <= 0
                        ||editText3.getText().toString().trim().length() <= 0||editText4.getText().toString().trim().length() <= 0||
                        editText6.getText().toString().trim().length() <= 0 ||editText7.getText().toString().trim().length() <= 0) {
                    Toast.makeText(SignUpActivity.this, "please fill all the fields", Toast.LENGTH_SHORT).show();
                }else{
                    startActivity(new Intent(SignUpActivity.this, Result.class));
                }
            }
        });
    }
}
