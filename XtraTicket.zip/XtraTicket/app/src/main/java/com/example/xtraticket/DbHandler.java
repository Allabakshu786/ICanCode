package com.example.xtraticket;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import java.util.ArrayList;
import android.util.Log;

import java.util.HashMap;

public class DbHandler extends SQLiteOpenHelper{

    public static String DATABASE_NAME = "XtraTicket";
    private static final int DATABASE_VERSION = 1;
    private static final String TABLE_IHAVE = "ihave";
    private static final String TABLE_INEED = "ineed";
    private static final String KEY_NAME = "name";
    private static final String KEY_MOBILE = "mobile";
    private static final String KEY_NUMOFTIC = "numoftic";
    private static final String KEY_THEATRE = "theatre";
    private static final String KEY_TIME = "time";
    private static final String KEY_AMT = "amt";

    private static final String CREATE_TABLE_IHAVE = "CREATE TABLE "
            + TABLE_IHAVE + "(" + KEY_NAME
            + " TEXT," + KEY_MOBILE + " TEXT ,"+KEY_THEATRE+"TEXT ,"+KEY_NUMOFTIC+"TEXT ,"+KEY_TIME+"TEXT ,"+KEY_AMT +"TEXT);";

    private static final String CREATE_TABLE_INEED = "CREATE TABLE "
            + TABLE_INEED + "(" + KEY_NAME
            + " TEXT," + KEY_MOBILE + " TEXT ,"+KEY_THEATRE+"TEXT ,"+KEY_NUMOFTIC+"TEXT ,"+KEY_TIME+"TEXT ,"+KEY_AMT +"TEXT);";

    public DbHandler(android.content.Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
        Log.d("table", CREATE_TABLE_IHAVE);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL(TABLE_IHAVE);
        db.execSQL(TABLE_INEED);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS '" + TABLE_IHAVE + "'");
        db.execSQL("DROP TABLE IF EXISTS '" + TABLE_INEED + "'");
        onCreate(db);
    }


    public void addUser(String name, String hobby, String city) {
        SQLiteDatabase db = this.getWritableDatabase();
        //adding user name in users table
        ContentValues NAME = new ContentValues();
        NAME.put(KEY_NAME, name);
        // db.insert(TABLE_USER, null, values);
        long id = db.insertWithOnConflict(TABLE_IHAVE, null, NAME, SQLiteDatabase.CONFLICT_IGNORE);

    }


}
